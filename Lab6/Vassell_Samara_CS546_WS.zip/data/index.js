//Here you will require both data files and export them as shown in lecture code where there is more than one data file. Look at lecture 6 lecture code for example

import movieDataFunctions from './movies.js';
import reviewDataFunctions from './reviews.js';

export const reviewData = reviewDataFunctions;
export const movieData = movieDataFunctions;